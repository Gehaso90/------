a = int(input("Введите первое число: "))
b = int(input("Введите второе число: "))
c = int(input("Введите третье число: "))

sum_of_numbers = a + b + c


product_of_numbers = a * b * c


print("Сумма чисел: ", sum_of_numbers)
print("Произведение чисел: ", product_of_numbers)