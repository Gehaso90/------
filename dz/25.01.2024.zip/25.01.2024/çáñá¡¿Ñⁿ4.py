print("To be")
print("or not")
print("to be")