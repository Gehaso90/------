print("Life is what")
print("when")
print("you’re busy making other", "- John Lennon")