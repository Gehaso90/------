
expression = input("Введите  выражение (например, 1+1: 25*5 :250-99): ")


parts = expression.split()


if len(parts) != 3 or parts[1] not in ['+', '-', '*']:
    print("Некорректное  выражение")
else:
    
    if parts[1] == '+':
        result = int(parts[0]) + int(parts[2])
    elif parts[1] == '-':
        result = int(parts[0]) - int(parts[2])
    else:
        result = int(parts[0]) * int(parts[2])

  
    print("Результат выражения:", result)

















































