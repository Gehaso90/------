import random


numbers = [random.randint(-10, 10) for _ in range(10)]


min_num = min(numbers)
max_num = max(numbers)

neg_count = 0
zero_count = 0
pos_count = 0

for num in numbers:
    if num < 0:
        neg_count += 1
    elif num == 0:
        zero_count += 1
    else:
        pos_count += 1


print(f"Минимальный элемент списка: {min_num}")
print(f"Максимальный элемент списка: {max_num}")
print(f"Количество отрицательных элементов: {neg_count}")
print(f"Количество нулей: {zero_count}")
print(f"Количество положительных элементов: {pos_count}")